/**
 * 
 */
/**
 * 
 */
module campus_course_records_manager {
}